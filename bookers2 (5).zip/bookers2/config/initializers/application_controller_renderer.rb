# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '28179c676fe735a8bab59a82b69a248e01e7d006d9169843d880e2d447588fc67dea68e25094185ad3c49fdae48c3d028e828e3c9544ca50d3819243fe1067a0'